// ==UserScript==
// @name        Punch Button Highlighter
// @namespace   http://tampermonkey.net/
// @version     1.1
// @description Dynamically changes color of punch buttons based on which punch needs to be made next
// @author      @alexanmendoza
// @include     https://track.tesla.com/employee/dashboard
// @grant       none
// ==/UserScript==

(function() {
    'use strict';

    // CSS selector for the table (chains multiple classes with dots)
    const tableSelector = 'table.tds-table.tds-table--row_border';

    // Replace with your unique data-testid values
    const elementIfMoreInsTestId = 'clockOut_btn';
    const elementOtherwiseTestId = 'clockIn_btn';

    // Function to evaluate counts and update colors
    function updateColors() {
        const table = document.querySelector(tableSelector);
        if (!table) {
            console.log('Table not found. Skipping update.');
            return;
        }

        // Find all punch-in TDs and filter those with non-empty text content
        const punchIns = Array.from(table.querySelectorAll('td.punch.punch--in'))
            .filter(td => td.textContent.trim() !== '');
        const inCount = punchIns.length;

        // Find all punch-out TDs and filter those with non-empty text content
        const punchOuts = Array.from(table.querySelectorAll('td.punch.punch--out'))
            .filter(td => td.textContent.trim() !== '');
        const outCount = punchOuts.length;

        // Find the elements
        const elementIfMoreIns = document.querySelector(`[data-testid="${elementIfMoreInsTestId}"]`);
        const elementOtherwise = document.querySelector(`[data-testid="${elementOtherwiseTestId}"]`);

        if (!elementIfMoreIns || !elementOtherwise) {
            return;
        }

        // Reset both to default
        elementIfMoreIns.style.backgroundColor = '';
        elementOtherwise.style.backgroundColor = '';

        // Apply green to the appropriate one
        const color = 'lightgreen';
        if (inCount > outCount) {
            elementIfMoreIns.style.backgroundColor = color;
        } else {
            elementOtherwise.style.backgroundColor = color;
        }

        console.log(`Colors updated: inCount=${inCount}, outCount=${outCount}`);
    }

    // Debounce function to prevent excessive calls
    let debounceTimeout;
    function debouncedUpdate() {
        clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(updateColors, 300);  // Adjust delay as needed
    }

    // Function to set up table observer once table is found
    function setupTableObserver(table) {
        const tableObserver = new MutationObserver(() => debouncedUpdate(table));
        tableObserver.observe(table, {
            childList: true,
            subtree: true  // Observe changes deep in the table's subtree
        });
    }

    // Immediate setup: Check for table and set up body observer
    let table = document.querySelector(tableSelector);

    if (table) {
        // Table already exists: Run initial update and set up observer
        updateColors(table);
        setupTableObserver(table);
    } else {
        // Set up MutationObserver on body to detect if table is added later
        const bodyObserver = new MutationObserver((mutations) => {
            table = document.querySelector(tableSelector);
            if (table) {
                updateColors(table);
                setupTableObserver(table);
                bodyObserver.disconnect();  // Stop observing body once table is found
            }
        });

        bodyObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
})();