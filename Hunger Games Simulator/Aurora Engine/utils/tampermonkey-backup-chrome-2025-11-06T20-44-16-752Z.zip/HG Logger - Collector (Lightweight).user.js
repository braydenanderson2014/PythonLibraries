// ==UserScript==
// @name HG Logger - Collector (Lightweight)
// @namespace http://tampermonkey.net/
// @version 1.0
// @description Lightweight console logger that captures logs from all websites and stores them for the dashboard
// @author Otter Logic LLC
// @match *://*/*
// @grant GM_setValue
// @grant GM_getValue
// @grant unsafeWindow
// @run-at document-start
// ==/UserScript==

(function() {
  'use strict';

  // ===== CONFIGURATION =====
  const MAX_LOGS_PER_SITE = 1000;
  const STORAGE_KEY = 'hg_logger_all_logs';
  const STATS_KEY = 'hg_logger_stats';

  // Blacklist for sites to skip (ads, tracking, etc.)
  const BLACKLIST = [
    'amazon-adsystem.com',
    'googlesyndication.com',
    'doubleclick.net',
    'googletagmanager.com',
    'googletagservices.com',
    'google-analytics.com',
    'facebook.net',
    'fbcdn.net'
  ];

  // Check if current site is blacklisted
  const isBlacklisted = BLACKLIST.some(domain => location.host.includes(domain));
  if (isBlacklisted) {
    return; // Exit early for blacklisted domains
  }

  // ===== SAFE LOGGING (for debugging collector itself) =====
  const origLog = console.log.bind(console);
  function safeLog(...args) {
    origLog('[HG COLLECTOR]', ...args);
  }

  safeLog('Initializing on', location.host);

  // ===== HELPER FUNCTIONS =====
  function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
  }

  function serializeArgs(args) {
    return args.map(arg => {
      try {
        if (arg instanceof Error) {
          return {
            type: 'error',
            name: arg.name,
            message: arg.message,
            stack: arg.stack
          };
        }
        if (typeof arg === 'string') return arg;
        if (typeof arg === 'number' || typeof arg === 'boolean') return arg;
        if (arg === null || arg === undefined) return String(arg);

        // Try to serialize objects
        return JSON.parse(JSON.stringify(arg, (k, v) => {
          if (typeof v === 'function') return '[Function]';
          if (v instanceof Error) return { error: v.message };
          return v;
        }));
      } catch (e) {
        return String(arg) || '[unserializable]';
      }
    });
  }

  function saveLogs(logs) {
    try {
      GM_setValue(STORAGE_KEY, logs);
    } catch (e) {
      safeLog('Failed to save logs:', e.message);
    }
  }

  function loadLogs() {
    try {
      return GM_getValue(STORAGE_KEY, {});
    } catch (e) {
      safeLog('Failed to load logs:', e.message);
      return {};
    }
  }

  function updateStats() {
    try {
      const allLogs = loadLogs();
      const stats = {
        totalSites: Object.keys(allLogs).length,
        totalLogs: Object.values(allLogs).flat().length,
        lastUpdate: new Date().toISOString(),
        siteBreakdown: {}
      };

      Object.keys(allLogs).forEach(host => {
        stats.siteBreakdown[host] = allLogs[host].length;
      });

      GM_setValue(STATS_KEY, stats);
    } catch (e) {
      safeLog('Failed to update stats:', e.message);
    }
  }

  // ===== CONSOLE HOOKS =====
  const methods = ['log', 'info', 'warn', 'error', 'debug'];
  const pageConsole = typeof unsafeWindow !== 'undefined' ? unsafeWindow.console : console;
  const originalMethods = {};

  // Save original methods
  methods.forEach(method => {
    originalMethods[method] = pageConsole[method].bind(pageConsole);
  });

  safeLog('Installing hooks for:', methods);

  // Install hooks
  methods.forEach(method => {
    pageConsole[method] = function(...args) {
      // Skip HG Logger's own debug messages
      if (args.length > 0 && typeof args[0] === 'string' && args[0].includes('[HG COLLECTOR]')) {
        return originalMethods[method].apply(this, args);
      }

      // Capture the log
      try {
        const entry = {
          id: generateId(),
          method: method,
          args: serializeArgs(args),
          host: location.host,
          href: location.href,
          origin: location.origin,
          timestamp: new Date().toISOString(),
          userAgent: navigator.userAgent.substring(0, 100)
        };

        // Load current logs
        const allLogs = loadLogs();

        // Initialize array for this host if needed
        if (!allLogs[location.host]) {
          allLogs[location.host] = [];
        }

        // Add new entry
        allLogs[location.host].push(entry);

        // Keep only last MAX_LOGS_PER_SITE entries per site
        if (allLogs[location.host].length > MAX_LOGS_PER_SITE) {
          allLogs[location.host] = allLogs[location.host].slice(-MAX_LOGS_PER_SITE);
        }

        // Save back to storage
        saveLogs(allLogs);

        // Update stats (throttled - only every 10th log)
        if (allLogs[location.host].length % 10 === 0) {
          updateStats();
        }
      } catch (e) {
        safeLog('Capture error:', e.message);
      }

      // Call original console method
      return originalMethods[method].apply(this, args);
    };
  });

  // Hook console.clear
  const originalClear = pageConsole.clear ? pageConsole.clear.bind(pageConsole) : null;
  if (originalClear) {
    pageConsole.clear = function() {
      try {
        const entry = {
          id: generateId(),
          method: 'clear',
          args: ['[Console was cleared]'],
          host: location.host,
          href: location.href,
          origin: location.origin,
          timestamp: new Date().toISOString(),
          userAgent: navigator.userAgent.substring(0, 100)
        };

        const allLogs = loadLogs();
        if (!allLogs[location.host]) allLogs[location.host] = [];
        allLogs[location.host].push(entry);
        saveLogs(allLogs);
      } catch (e) {
        safeLog('Clear capture error:', e.message);
      }

      return originalClear.apply(this, arguments);
    };
  }

  // Hook unhandled errors
  const pageWindow = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;

  pageWindow.addEventListener('error', (event) => {
    try {
      const entry = {
        id: generateId(),
        method: 'error',
        args: [{
          type: 'uncaught-error',
          message: event.message,
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno,
          error: event.error ? {
            name: event.error.name,
            message: event.error.message,
            stack: event.error.stack
          } : null
        }],
        host: location.host,
        href: location.href,
        origin: location.origin,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent.substring(0, 100)
      };

      const allLogs = loadLogs();
      if (!allLogs[location.host]) allLogs[location.host] = [];
      allLogs[location.host].push(entry);
      saveLogs(allLogs);
    } catch (e) {
      safeLog('Error event capture failed:', e.message);
    }
  });

  pageWindow.addEventListener('unhandledrejection', (event) => {
    try {
      const entry = {
        id: generateId(),
        method: 'error',
        args: [{
          type: 'unhandled-rejection',
          reason: event.reason ? String(event.reason) : 'Unknown reason'
        }],
        host: location.host,
        href: location.href,
        origin: location.origin,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent.substring(0, 100)
      };

      const allLogs = loadLogs();
      if (!allLogs[location.host]) allLogs[location.host] = [];
      allLogs[location.host].push(entry);
      saveLogs(allLogs);
    } catch (e) {
      safeLog('Rejection event capture failed:', e.message);
    }
  });

  safeLog('Hooks installed successfully');

  // Update stats on load
  updateStats();

  // Expose debug interface
  if (typeof unsafeWindow !== 'undefined') {
    unsafeWindow.HGCollectorDebug = {
      getStats: () => GM_getValue(STATS_KEY, {}),
      getCurrentSiteLogs: () => {
        const allLogs = loadLogs();
        return allLogs[location.host] || [];
      },
      getAllLogs: () => loadLogs(),
      clearCurrentSite: () => {
        const allLogs = loadLogs();
        delete allLogs[location.host];
        saveLogs(allLogs);
        updateStats();
        safeLog('Cleared logs for', location.host);
      },
      clearAllLogs: () => {
        GM_setValue(STORAGE_KEY, {});
        GM_setValue(STATS_KEY, { totalSites: 0, totalLogs: 0 });
        safeLog('Cleared all logs');
      }
    };
  }

})();
